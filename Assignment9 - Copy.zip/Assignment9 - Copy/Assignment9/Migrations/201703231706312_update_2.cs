namespace Assignment9.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class update_2 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Albums", "UrlAlbum", c => c.String(nullable: false, maxLength: 500));
            AlterColumn("dbo.Artists", "UrlArtist", c => c.String(nullable: false, maxLength: 500));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Artists", "UrlArtist", c => c.String(nullable: false, maxLength: 200));
            AlterColumn("dbo.Albums", "UrlAlbum", c => c.String(nullable: false, maxLength: 200));
        }
    }
}
