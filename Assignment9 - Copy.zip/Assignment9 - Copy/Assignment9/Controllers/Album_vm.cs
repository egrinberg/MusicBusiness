﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Assignment9.Controllers
{
    public class AlbumBase
    {
        public AlbumBase()
        {
            ReleaseDate = DateTime.Now;
            
        }

        public int Id { get; set; }

        [Required, StringLength(100)]
        [Display(Name = "Album name")]
        public string Name { get; set; }

        [DataType(DataType.Date),Display(Name = "Release date")]
        public DateTime ReleaseDate { get; set; }

        // Get from Apple iTunes Preview, Amazon, or Wikipedia
        [Required, StringLength(500),Display(Name = "Album cover art")]
        public string UrlAlbum { get; set; }

        [Required,Display(Name = "Album's primary genre")]
        public string Genre { get; set; }

        // User name who looks after the album
        [Required, StringLength(200)]
        public string Coordinator { get; set; }

        [DataType(DataType.MultilineText),StringLength(5000)]
        [Display(Name = "Album depiction")]
        public string Depiction { get; set; }

        
    }

    public class AlbumWithDetails:AlbumBase
    {
        public AlbumWithDetails()
        {
            Artists = new List<ArtistBase>();
            Tracks = new List<TrackBase>();
        }
        public IEnumerable<ArtistBase> Artists { get; set; }

        public IEnumerable<TrackBase> Tracks { get; set; }

    }

    public class AlbumAdd
    {
        public AlbumAdd()
        {
            ReleaseDate = DateTime.Now.AddYears(-5);
            Genre = "";
            Name = "";
            UrlAlbum = "";
        }
        [Required, StringLength(100)]
        public string Name { get; set; }

        public DateTime ReleaseDate { get; set; }
        
        [Required, StringLength(500)]
        public string UrlAlbum { get; set; }

        [Required]
        public string Genre { get; set; }
        
        [StringLength(5000)]
        public string Depiction { get; set; }

        [Range(1, Int32.MaxValue)]
        public int ArtistId { get; set; }

    }
    public class AlbumAddForm
    {
        public AlbumAddForm()
        {
            ReleaseDate = DateTime.Now.AddYears(-5);
            Name = "";
            UrlAlbum = "";
        }
        [Required, StringLength(100)]
        [Display(Name = "Album name")]
        public string Name { get; set; }

        [DataType(DataType.Date), Display(Name = "Release date")]
        public DateTime ReleaseDate { get; set; }

        // Get from Apple iTunes Preview, Amazon, or Wikipedia
        [Required, StringLength(500), Display(Name = "URL to album image (cover art)")]
        public string UrlAlbum { get; set; }

               
        [DataType(DataType.MultilineText), StringLength(5000), Display(Name = "Album depiction")]
        public string Depiction { get; set; }

        [Display(Name = "Album's primary genre")]
        public SelectList GenreList { get; set; }

        [Range(1, Int32.MaxValue)]
        [HiddenInput]
        public int ArtistId { get; set; }

        [Display(Name = "Album Name")]
        public string ArtistName { get; set; }

    }
}