﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Assignment9.Controllers
{
    [Authorize]
    public class ArtistsController : Controller
    {
        Manager m = new Manager();
        // GET: Artists
        public ActionResult Index()
        {
            return View(m.ArtistGetAll());
        }

        // GET: Artists/Details/5
        public ActionResult Details(int? id)
        {
            var o = m.ArtistGetByIdWithDetail(id.GetValueOrDefault());
            if (o == null)
            {
                return HttpNotFound();
            }
            else
            {
                return View(o);
            }           
        }

        // GET: Artists/Create
        [Authorize(Roles = "Executive")]
        public ActionResult Create()
        {
            var form = new ArtistAddForm();
            form.GenreList = new SelectList(m.GenreGetAll().Select(g => g.Name));
            return View(form);
        }

        // POST: Artists/Create
        [Authorize(Roles = "Executive")]
        [HttpPost, ValidateInput(false)]
        public ActionResult Create(ArtistAdd newItem)
        {
            if (!ModelState.IsValid)
            {
                return RedirectToAction("create");
            }

            var addedItem = m.ArtistAdd(newItem);

            if (addedItem == null)
            {
                return RedirectToAction("create");
            }
            else
            {
                return RedirectToAction("details", new { id = addedItem.Id });
            }
        }

        [Authorize(Roles = "Coordinator")]
        [Route("artists/{id}/addalbum")]
        public ActionResult AddAlbum(int? id)
        {
            var a = m.ArtistGetByIdWithDetail(id.GetValueOrDefault());

            if (a == null)
            {
                return HttpNotFound();
            }
            else
            {
                var form = new AlbumAddForm();
                form.ArtistName = a.Name;
                form.ArtistId = a.Id;
                form.GenreList = new SelectList(m.GenreGetAll().Select(g => g.Name));
                return View(form);
            }

        }
        [Authorize(Roles = "Coordinator")]
        [Route("artists/{id}/addalbum")]
        [HttpPost, ValidateInput(false)]
        public ActionResult AddAlbum(AlbumAdd newItem)
        {
            if (!ModelState.IsValid)
            {
                return RedirectToAction("addalbum");
            }

            var addedItem = m.AlbumAdd(newItem);

            if (addedItem == null)
            {
                return RedirectToAction("addalbum");
            }
            else
            {
                return RedirectToAction("details", "albums", new { id = addedItem.Id });
            }
        }

        // GET: Artists/Edit/5
        [Authorize(Roles = "Executive")]
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Artists/Edit/5
        [Authorize(Roles = "Executive")]
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Artists/Delete/5
        [Authorize(Roles = "Executive")]
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Artists/Delete/5
        [Authorize(Roles = "Executive")]
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
